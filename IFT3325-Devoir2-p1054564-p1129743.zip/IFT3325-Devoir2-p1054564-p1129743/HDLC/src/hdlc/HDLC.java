package hdlc;

public class HDLC {

    public static void main(String[] args) {

    }
    
}
