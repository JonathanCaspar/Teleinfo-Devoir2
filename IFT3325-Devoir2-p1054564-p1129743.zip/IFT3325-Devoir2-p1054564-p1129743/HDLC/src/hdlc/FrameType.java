package hdlc;


public enum FrameType {
    I,
    C,
    A,
    R,
    F,
    P
}
